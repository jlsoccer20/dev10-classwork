package learn.field_agent.domain;

public enum ResultType {
    SUCCESS,
    INVALID,
    NOT_FOUND
}
